/**
 @mainpage M-Stack
 
 @section Intro
 This is M-Stack, a free USB Device Stack for PIC Microcontrollers.

 For more information, see the <a href="http://www.signal11.us/oss/m-stack">main web page.</a>

 For API documentation, see the <a href="group__public__api.html">Public API Page.</a>
 
 */
 
 